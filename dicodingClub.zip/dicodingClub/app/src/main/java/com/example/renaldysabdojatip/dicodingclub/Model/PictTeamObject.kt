package com.example.renaldysabdojatip.dicodingclub.Model

import com.google.gson.annotations.SerializedName

data class PictTeamObject (
        @SerializedName("strTeamBadge")
        val strTeamBadge : String?
)